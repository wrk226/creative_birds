# -*- coding: utf-8 -*-
#
__version__ = "0.4.3"
__author__ = "Nico Schlömer"
__author_email__ = "nico.schloemer@gmail.com"
__website__ = "https://github.com/nschloe/meshzoo"
__status__ = "Development Status :: 4 - Beta"
__license__ = "License :: OSI Approved :: MIT License"
